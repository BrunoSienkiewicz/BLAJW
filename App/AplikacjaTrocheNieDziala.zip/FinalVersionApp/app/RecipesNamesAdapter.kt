class RecipesNamesAdapter {
}