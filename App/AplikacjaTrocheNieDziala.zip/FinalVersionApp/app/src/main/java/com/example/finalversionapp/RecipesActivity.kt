package com.example.finalversionapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RecipesActivity : AppCompatActivity() {

//    private lateinit var viewModel :RecipesNames

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes)

//        val matchingRecipes = intent.getParcelableArrayListExtra<>("matchingRecipes")

    }
}