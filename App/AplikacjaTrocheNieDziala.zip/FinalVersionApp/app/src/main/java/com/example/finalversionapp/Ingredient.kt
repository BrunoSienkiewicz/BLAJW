package com.example.finalversionapp

data class Ingredient(val name: String, val quantity: Int) {
    companion object {
        fun fromString(string: String): Ingredient {
            val parts = string.split(" - ")
            val name = parts[0]
            val quantity = parts[1].toInt()
            return Ingredient(name, quantity)
        }
    }
}
