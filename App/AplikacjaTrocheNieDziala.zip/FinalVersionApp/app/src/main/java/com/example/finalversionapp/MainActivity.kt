package com.example.finalversionapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.opencsv.CSVReader
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: IngredientsViewModel
    private lateinit var adapter: IngredientsAdapter
    private val recipes = mutableListOf<RecipeName>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        Z TYM KODEM APLIKACJE WYWALA PO STARCIE
        val manager = assets
        val inputStream = manager.open("database(1).csv")
        val reader = CSVReader(inputStream.reader())
        val records = reader.readAll()
        for (record in records) {
            val id = record[0].toInt()
            val name = record[1]
            val type = record[2].split(",")
            val time = record[3].toInt()
            val ingredients = record[4].split(",").map { Ingredient.fromString(it) }
            val steps = record[5].split(",")
            recipes.add(RecipeName(id, name, type, time, ingredients, steps))
        }



        viewModel = ViewModelProvider(this).get(IngredientsViewModel::class.java)
        adapter = IngredientsAdapter(viewModel.ingredients)
        ingredientRecyclerView.adapter = adapter
        ingredientRecyclerView.layoutManager = LinearLayoutManager(this)

        addButton.setOnClickListener {
            val name = ingredientNameEditText.text.toString()
            val quantity = ingredientQuantityEditText.text.toString().toInt()
            viewModel.addIngredient(Ingredient(name, quantity))
            adapter.notifyItemInserted(viewModel.ingredients.size - 1)
            ingredientNameEditText.text.clear()
            ingredientQuantityEditText.text.clear()
        }
        suggestRecipesButton.setOnClickListener {
            val intent = Intent(this, RecipesActivity::class.java)
            startActivity(intent)
        }
    }}
